package com.sandeep.eBookStore_Cloud_Gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreCloudGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
