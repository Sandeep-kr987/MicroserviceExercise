package com.sandeep.eBookStore_Consumers_Feign;

public class BookDetails {

	 private Long id;

	    private String bookTitle;
	    private String bookPublisher;
	    private String bookIsbn;
	    private int bookNumberOfPages;
	    private int bookYear;
		public BookDetails() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getBookTitle() {
			return bookTitle;
		}
		public void setBookTitle(String bookTitle) {
			this.bookTitle = bookTitle;
		}
		public String getBookPublisher() {
			return bookPublisher;
		}
		public void setBookPublisher(String bookPublisher) {
			this.bookPublisher = bookPublisher;
		}
		public String getBookIsbn() {
			return bookIsbn;
		}
		public void setBookIsbn(String bookIsbn) {
			this.bookIsbn = bookIsbn;
		}
		public int getBookNumberOfPages() {
			return bookNumberOfPages;
		}
		public void setBookNumberOfPages(int bookNumberOfPages) {
			this.bookNumberOfPages = bookNumberOfPages;
		}
		public int getBookYear() {
			return bookYear;
		}
		public void setBookYear(int bookYear) {
			this.bookYear = bookYear;
		}
	    
	    
}
