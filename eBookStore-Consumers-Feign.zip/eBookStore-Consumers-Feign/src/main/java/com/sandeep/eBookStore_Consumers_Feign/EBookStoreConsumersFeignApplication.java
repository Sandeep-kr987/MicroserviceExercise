package com.sandeep.eBookStore_Consumers_Feign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

@SpringBootApplication
@EnableFeignClients
public class EBookStoreConsumersFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumersFeignApplication.class, args);
	}

}
