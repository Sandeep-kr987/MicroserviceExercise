package com.sandeep.eBookStore_Consumers_Feign;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class BookConsumerRestController {

    @Autowired
    private BookServiceProxy bookServiceProxy;

    // Endpoint for getting all books
    @GetMapping("/get-books")
    public ResponseEntity<List<BookDetails>> getAllBooks() {
        List<BookDetails> books = bookServiceProxy.getAllBooks();
        return ResponseEntity.ok(books);
    }

    // Endpoint for getting a book by ID
    @GetMapping("/get-books/{id}")
    public ResponseEntity<BookDetails> getBookById(@PathVariable Long id) {
        BookDetails book = bookServiceProxy.getBookById(id);
        return book != null ? ResponseEntity.ok(book) : ResponseEntity.notFound().build();
    }
}
