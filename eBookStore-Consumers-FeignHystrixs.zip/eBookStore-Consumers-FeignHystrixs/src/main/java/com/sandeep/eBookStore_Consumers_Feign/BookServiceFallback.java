package com.sandeep.eBookStore_Consumers_Feign;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class BookServiceFallback implements BookServiceProxy {

    @Override
    public List<BookDetails> getAllBooks() {
        // Fallback logic here
        return Collections.emptyList(); // Or any default response
    }

    @Override
    public BookDetails getBookById(Long id) {
        // Fallback logic here
        return null; // Or a default BookDetails object
    }
}
