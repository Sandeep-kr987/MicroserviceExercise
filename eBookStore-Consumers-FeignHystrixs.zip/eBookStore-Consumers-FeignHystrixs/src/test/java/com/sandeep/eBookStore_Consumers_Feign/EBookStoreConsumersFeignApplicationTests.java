package com.sandeep.eBookStore_Consumers_Feign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumersFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
