package com.sandeep.eBookStore_Consumers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;



@RestController
@Scope("request")
public class BookConsumerRestController {

	 @Autowired
	    private RestTemplate restTemplate; // Corrected type

	    @GetMapping("/get-books/{id}")
	    public BookDetails getBookById(@PathVariable Long id) {
	        // Call the book service using its application name
	        String url = "http://book-service/api/books/" + id;
	        return restTemplate.getForObject(url, BookDetails.class);
	    }
}
