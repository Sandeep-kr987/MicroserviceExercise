package com.sandeep.eBookStore_Consumers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBookStoreConsumersApplication {

	public static void main(String[] args) {
		SpringApplication.run(EBookStoreConsumersApplication.class, args);
	}

}
