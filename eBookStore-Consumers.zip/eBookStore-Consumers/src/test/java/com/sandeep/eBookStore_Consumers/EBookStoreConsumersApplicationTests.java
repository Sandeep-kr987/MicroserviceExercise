package com.sandeep.eBookStore_Consumers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumersApplicationTests {

	@Test
	void contextLoads() {
	}

}
