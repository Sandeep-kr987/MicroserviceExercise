package com.sandeep.eBookStore_Eureka_Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
