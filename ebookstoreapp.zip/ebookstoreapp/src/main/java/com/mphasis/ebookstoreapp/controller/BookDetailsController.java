package com.mphasis.ebookstoreapp.controller;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.ebookstoreapp.model.BookDetails;
import com.mphasis.ebookstoreapp.service.BookDetailsService;

@RestController
@RequestMapping("/api/books")
@Scope(value = "singleton")
public class BookDetailsController {

    private static final Logger logger = LoggerFactory.getLogger(BookDetailsController.class);

    @Autowired
    private BookDetailsService bookStoreService;

    @PostMapping
    public ResponseEntity<BookDetails> addBook(@RequestBody BookDetails bookDetails) {
        logger.debug("Adding book: {}", bookDetails);
        BookDetails savedBook = bookStoreService.saveBook(bookDetails);
        logger.debug("Book added: {}", savedBook);
        return ResponseEntity.ok(savedBook);
    }

    @PutMapping("/{book_id}")
    public ResponseEntity<BookDetails> updateBook(@PathVariable Long book_id, @RequestBody BookDetails bookDetails) {
        logger.debug("Updating book with id {}: {}", book_id, bookDetails);
        BookDetails updatedBook = bookStoreService.updateBook(book_id, bookDetails);
        logger.debug("Book updated: {}", updatedBook);
        return ResponseEntity.ok(updatedBook);
    }

    @GetMapping
    public List<BookDetails> getAllBooks(@RequestParam(required = false) Integer year) {
        logger.debug("Fetching all books, filter by year: {}", year);
        List<BookDetails> books = (year != null) ? bookStoreService.findByYear(year) : bookStoreService.getAllBooks();
        logger.debug("Books fetched: {}", books.size());
        return books;
    }

    @GetMapping("/{book_id}")
    public ResponseEntity<BookDetails> getBookById(@PathVariable Long book_id) {
        logger.debug("Fetching book with id {}", book_id);
        Optional<BookDetails> bookDetails = bookStoreService.getBookById(book_id);
        return bookDetails.map(ResponseEntity::ok)
                          .orElseGet(() -> {
                              logger.debug("Book with id {} not found", book_id);
                              return ResponseEntity.notFound().build();
                          });
    }

    @DeleteMapping("/{book_id}")
    public ResponseEntity<Void> deleteBook(@PathVariable Long book_id) {
        logger.debug("Deleting book with id {}", book_id);
        bookStoreService.deleteBook(book_id);
        logger.debug("Book with id {} deleted", book_id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/title/{book_title}")
    public List<BookDetails> getBooksByTitle(@PathVariable String book_title) {
        logger.debug("Fetching books with title {}", book_title);
        List<BookDetails> books = bookStoreService.findByBookTitle(book_title);
        logger.debug("Books fetched with title {}: {}", book_title, books.size());
        return books;
    }

    @GetMapping("/publisher/{book_publisher}")
    public List<BookDetails> getBooksByPublisher(@PathVariable String book_publisher) {
        logger.debug("Fetching books published by {}", book_publisher);
        List<BookDetails> books = bookStoreService.findByBookPublisherLike(book_publisher);
        logger.debug("Books fetched by publisher {}: {}", book_publisher, books.size());
        return books;
    }
}
