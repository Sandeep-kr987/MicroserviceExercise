package com.mphasis.ebookstoreapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mphasis.ebookstoreapp.model.BookDetails;

public interface BookDetailsRepository extends JpaRepository<BookDetails, Long> {

	// Custom query methods
    List<BookDetails> findByBookTitle(String title);
    List<BookDetails> findByBookPublisherLike(String publisher);
    List<BookDetails> findByBookYear(int year);
}
