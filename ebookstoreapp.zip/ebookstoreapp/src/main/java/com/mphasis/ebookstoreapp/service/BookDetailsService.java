package com.mphasis.ebookstoreapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mphasis.ebookstoreapp.model.BookDetails;
import com.mphasis.ebookstoreapp.repository.BookDetailsRepository;

@Service
public class BookDetailsService {
	
	@Autowired
    private BookDetailsRepository bookDetailsRepository;

    public List<BookDetails> getAllBooks() {
        return bookDetailsRepository.findAll();
    }
    
    public Optional<BookDetails> getBookById(Long id) {
        return bookDetailsRepository.findById(id);
    }
    
    public BookDetails saveBook(BookDetails bookDetails) {
        return bookDetailsRepository.save(bookDetails);
    }
    
    public BookDetails updateBook(Long id, BookDetails bookDetails) {
        bookDetails.setId(id);
        return bookDetailsRepository.save(bookDetails);
    }
    
    public void deleteBook(Long id) {
    	bookDetailsRepository.deleteById(id);
    }
    
    public List<BookDetails> findByBookTitle(String title) {
        return bookDetailsRepository.findByBookTitle(title);
    }

    public List<BookDetails> findByBookPublisherLike(String publisher) {
        return bookDetailsRepository.findByBookPublisherLike(publisher);
    }

    public List<BookDetails> findByYear(int year) {
        return bookDetailsRepository.findByBookYear(year);
    }
}
